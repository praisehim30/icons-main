---
title: Clipboard2 minus
categories:
  - Real world
tags:
  - copy
  - paste
---
